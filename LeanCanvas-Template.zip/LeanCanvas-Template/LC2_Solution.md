## Solution
> *Outline possible solution(s) for each problem.*

