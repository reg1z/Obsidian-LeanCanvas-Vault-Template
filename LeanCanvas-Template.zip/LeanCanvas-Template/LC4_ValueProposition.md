## Unique Value Proposition
> *Single, clear, and compelling message meant to turn a visitor into a prospect.*


---
## High Level Concept
> *List your "X for Y analogy" or another simplified description.*
> 
> *(e.g. Perplexity = Search-focused ChatGPT)*

