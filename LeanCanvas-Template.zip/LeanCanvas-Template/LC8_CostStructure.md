## Cost Structure
> *List your **fixed** and **variable** costs.*

