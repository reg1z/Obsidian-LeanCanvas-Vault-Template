## Customer Segments


---
## Early Adopters
