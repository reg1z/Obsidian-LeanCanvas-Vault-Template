## Customer Segments
> *Your target customers / users.*


---
## Early Adopters
> *Characteristics of your ideal customer.*