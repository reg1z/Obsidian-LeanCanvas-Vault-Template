## Unfair Advantage
> *Something that can't be easily copied or bought.*

